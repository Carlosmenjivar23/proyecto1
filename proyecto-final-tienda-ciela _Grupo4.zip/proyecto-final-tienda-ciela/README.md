# Sistema de Gesti�n para "La Tienda de la Ciela" 
 
## Proyecto Final - Ingenier�a de Software II 
 
### Integrantes: 
- Astrid Maradiaga 
- Carlos Menjivar 
- Ram�n Mej�a 
- Isa�as Bardales 
 
### Instrucciones de ejecuci�n 
 
#### Frontend (React) 
cd frontend 
npm install 
npm start 
 
#### Backend (Node.js/Express) 
cd backend 
npm install 
npm run dev 
 
### Arquitectura 
Ver docs/architecture.md 
 
### Trazabilidad HU > C�digo 
Ver docs/traceability.md 
