# Patrones de Dise�o Aplicados 
 
## Frontend 
1. **Componente Presentacional/Contenedor** - Separacion entre UI y logica. 
2. **Custom Hooks** - Reutilizacion de logica de estado (ej: useProducts). 
 
## Backend 
1. **Repository Pattern** - Abstraccion de acceso a datos. 
2. **Service Layer** - Separacion de logica de negocio. 
