# Evidencia de Principios SOLID 
 
## SRP (Single Responsibility) 
- ProductController solo maneja HTTP. 
- ProductService solo aplica logica de negocio. 
 
## OCP (Open/Closed) 
- Los repositorios implementan interfaces, permitiendo extension. 
 
## DIP (Dependency Inversion) 
- Inyeccion de dependencias en servicios. 
