# Trazabilidad HU > C�digo 
 
| HU  | Componente Frontend | Endpoint Backend | Servicio | Pruebas | 
|-----|---------------------|------------------|----------|---------| 
| HU01 | ProductList.tsx | GET /api/products | productService | (pendiente) | 
| HU02 | CheckoutPage.tsx | POST /api/orders | orderService | (pendiente) | 
