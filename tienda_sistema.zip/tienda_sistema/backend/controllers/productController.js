const Repo=require('../repositories/productRepository');
exports.list=(req,res)=> Repo.getAll((e,r)=> e?res.status(500).json({e}):res.json(r));