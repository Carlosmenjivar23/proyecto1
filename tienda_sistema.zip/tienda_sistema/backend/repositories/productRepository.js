const db=require('../db');
module.exports={
  getAll(cb){ db.all('SELECT * FROM products',[],cb); }
};