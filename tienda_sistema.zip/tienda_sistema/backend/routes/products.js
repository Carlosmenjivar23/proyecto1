const r=require('express').Router();
const c=require('../controllers/productController');
r.get('/',c.list);
module.exports=r;