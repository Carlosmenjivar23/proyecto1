const express=require('express');
const cors=require('cors');
const body=require('body-parser');
require('./db');

const app=express();
app.use(cors());
app.use(body.json());

app.use('/api/products', require('./routes/products'));
app.use('/api/orders', require('./routes/orders'));

app.listen(4000,()=>console.log('Backend OK'));
