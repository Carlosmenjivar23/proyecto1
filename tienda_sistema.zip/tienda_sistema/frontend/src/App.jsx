import React, { useEffect, useState } from "react";
import api from "./api";

export default function App() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    api.get("/products")
       .then(res => setProducts(res.data))
       .catch(err => console.error(err));
  }, []);

  return (
    <div style={{ padding: 20 }}>
      <h1>La Tienda de la Ciela (Vite + React)</h1>
      <h2>Catálogo de productos</h2>
      {products.length === 0 ? <p>No hay productos.</p> : (
        <ul>
          {products.map(p => (
            <li key={p.id}>
              {p.name} - L {p.price}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
